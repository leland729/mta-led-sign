#!/usr/bin/env node

/**
 * NYC Subway LED Sign Server
 * 
 * Fetches MTA GTFS-Realtime data, parses protobuf, caches results,
 * and serves JSON API for Matrix Portal S3 devices.
 * 
 * Optimized for Raspberry Pi 3 B+ with memory constraints.
 */

const express = require('express');
const fetch = require('node-fetch');
const NodeCache = require('node-cache');
const cors = require('cors');
const helmet = require('helmet');
const compression = require('compression');
const GtfsRealtimeBindings = require('gtfs-realtime-bindings');
require('dotenv').config();

const app = express();
const PORT = process.env.PORT || 3000;

// Cache with 30 second TTL, check for expired keys every 60 seconds
const cache = new NodeCache({ stdTTL: 30, checkperiod: 60 });

// Middleware - optimized for Pi 3 performance
app.use(helmet());
app.use(compression()); // Reduce bandwidth on Pi 3's limited network
app.use(cors());
app.use(express.json({ limit: '1mb' }));
app.use(express.static('public', { maxAge: '1d' })); // Cache static files

// MTA API configuration
const MTA_API_KEY = process.env.MTA_API_KEY;
const GTFS_FEEDS = {
  // G train is in the B-D-F-M feed
  'BDFM': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs-bdfm',
  'ACE': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs-ace',
  'NQRW': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs-nqrw',
  'L': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs-l',
  '123456S': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs',
  '7': 'https://api-endpoint.mta.info/Dataservice/mtagtfsfeeds/nyct%2Fgtfs-7'
};

// NYC Subway stations database (subset for demo - Greenpoint area)
const STATIONS = {
  'G22': {
    stop_id: 'G22',
    stop_name: 'Greenpoint Av',
    lat: 40.731352,
    lon: -73.954449,
    routes: ['G'],
    feed_group: 'BDFM'
  },
  'G24': {
    stop_id: 'G24', 
    stop_name: 'Nassau Av',
    lat: 40.724635,
    lon: -73.951277,
    routes: ['G'],
    feed_group: 'BDFM'
  },
  'G26': {
    stop_id: 'G26',
    stop_name: 'Metropolitan Av',
    lat: 40.712204,
    lon: -73.951418,
    routes: ['G'],
    feed_group: 'BDFM'
  },
  'L03': {
    stop_id: 'L03',
    stop_name: 'Metropolitan Av',
    lat: 40.712204,
    lon: -73.951418,
    routes: ['L'],
    feed_group: 'L'
  }
};

/**
 * Fetch and parse GTFS-RT data for a specific feed
 * Includes retry logic and error handling for Pi 3 stability
 */
async function fetchGtfsData(feedGroup, retries = 2) {
  const feedUrl = GTFS_FEEDS[feedGroup];
  if (!feedUrl) {
    throw new Error(`Unknown feed group: ${feedGroup}`);
  }

  const cacheKey = `gtfs_${feedGroup}`;
  const cached = cache.get(cacheKey);
  if (cached) {
    return cached;
  }

  for (let attempt = 0; attempt <= retries; attempt++) {
    try {
      console.log(`Fetching ${feedGroup} feed (attempt ${attempt + 1})`);
      
      const headers = {};
      if (MTA_API_KEY) {
        headers['x-api-key'] = MTA_API_KEY;
      }

      const response = await fetch(feedUrl, {
        headers,
        timeout: 10000 // 10 second timeout
      });

      if (!response.ok) {
        throw new Error(`HTTP ${response.status}: ${response.statusText}`);
      }

      const buffer = await response.buffer();
      const feed = GtfsRealtimeBindings.transit_realtime.FeedMessage.decode(buffer);
      
      // Cache the parsed feed for 30 seconds
      cache.set(cacheKey, feed, 30);
      console.log(`✓ Cached ${feedGroup} feed with ${feed.entity.length} entities`);
      
      return feed;
    } catch (error) {
      console.error(`✗ Attempt ${attempt + 1} failed for ${feedGroup}:`, error.message);
      
      if (attempt === retries) {
        throw error;
      }
      
      // Wait before retry (exponential backoff)
      await new Promise(resolve => setTimeout(resolve, 1000 * Math.pow(2, attempt)));
    }
  }
}

/**
 * Extract arrival times for a specific station and direction
 */
function extractArrivals(feed, stationId, direction) {
  const arrivals = [];
  const stopId = stationId + direction; // e.g., "G22N" or "G22S"
  
  for (const entity of feed.entity) {
    if (!entity.tripUpdate) continue;
    
    const trip = entity.tripUpdate.trip;
    const routeId = trip.routeId;
    
    for (const stopUpdate of entity.tripUpdate.stopTimeUpdate || []) {
      if (stopUpdate.stopId === stopId && stopUpdate.arrival) {
        const arrivalTime = parseInt(stopUpdate.arrival.time);
        const delay = stopUpdate.arrival.delay || 0;
        
        arrivals.push({
          routeId,
          arrivalTime,
          delay,
          vehicleId: trip.tripId
        });
      }
    }
  }
  
  // Sort by arrival time and return next 5
  return arrivals
    .sort((a, b) => a.arrivalTime - b.arrivalTime)
    .slice(0, 5);
}

/**
 * Get current time from server (for device time sync)
 */
function getCurrentTime() {
  return Math.floor(Date.now() / 1000);
}

// API Routes

/**
 * GET /api/stations
 * Returns list of all available stations
 */
app.get('/api/stations', (req, res) => {
  const stations = Object.values(STATIONS).map(station => ({
    stop_id: station.stop_id,
    stop_name: station.stop_name,
    lat: station.lat,
    lon: station.lon,
    routes: station.routes
  }));
  
  res.json(stations);
});

/**
 * GET /api/station/:id
 * Returns details for a specific station
 */
app.get('/api/station/:id', (req, res) => {
  const station = STATIONS[req.params.id];
  if (!station) {
    return res.status(404).json({ error: 'Station not found' });
  }
  
  res.json(station);
});

/**
 * GET /api/schedule/:stationId
 * Returns arrivals for both directions at a station
 */
app.get('/api/schedule/:stationId', async (req, res) => {
  try {
    const stationId = req.params.stationId;
    const station = STATIONS[stationId];
    
    if (!station) {
      return res.status(404).json({ error: 'Station not found' });
    }

    const feed = await fetchGtfsData(station.feed_group);
    
    const northbound = extractArrivals(feed, stationId, 'N');
    const southbound = extractArrivals(feed, stationId, 'S');
    
    res.json({
      station: station.stop_name,
      currentTime: getCurrentTime(),
      N: northbound,
      S: southbound,
      lastUpdated: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Error fetching schedule:', error);
    res.status(500).json({ 
      error: 'Failed to fetch schedule',
      currentTime: getCurrentTime(),
      N: [],
      S: []
    });
  }
});

/**
 * GET /api/schedule/:stationId/:route/:direction
 * Returns filtered arrivals for specific route and direction
 */
app.get('/api/schedule/:stationId/:route/:direction', async (req, res) => {
  try {
    const { stationId, route, direction } = req.params;
    const station = STATIONS[stationId];
    
    if (!station) {
      return res.status(404).json({ error: 'Station not found' });
    }

    const feed = await fetchGtfsData(station.feed_group);
    const arrivals = extractArrivals(feed, stationId, direction.toUpperCase());
    
    // Filter by route
    const filteredArrivals = arrivals.filter(arr => 
      arr.routeId.toLowerCase() === route.toLowerCase()
    );
    
    res.json({
      station: station.stop_name,
      route: route.toUpperCase(),
      direction: direction.toUpperCase(),
      currentTime: getCurrentTime(),
      arrivals: filteredArrivals,
      lastUpdated: new Date().toISOString()
    });
    
  } catch (error) {
    console.error('Error fetching filtered schedule:', error);
    res.status(500).json({ 
      error: 'Failed to fetch schedule',
      currentTime: getCurrentTime(),
      arrivals: []
    });
  }
});

/**
 * GET /api/time
 * Returns current server time for device synchronization
 */
app.get('/api/time', (req, res) => {
  res.json({
    timestamp: getCurrentTime(),
    iso: new Date().toISOString(),
    timezone: 'America/New_York'
  });
});

/**
 * GET /config
 * Device configuration page - generates secrets.py for CircuitPython
 */
app.get('/config', (req, res) => {
  const serverIp = req.ip === '::1' ? '192.168.0.162' : req.ip;
  
  res.send(`
<!DOCTYPE html>
<html>
<head>
    <title>Subway Sign Configuration</title>
    <style>
        body { font-family: monospace; margin: 40px; background: #f5f5f5; }
        .container { background: white; padding: 30px; border-radius: 8px; max-width: 800px; }
        pre { background: #2d3748; color: #e2e8f0; padding: 20px; border-radius: 4px; overflow-x: auto; }
        .step { margin: 20px 0; padding: 15px; background: #e6fffa; border-radius: 4px; }
        h2 { color: #2d3748; }
    </style>
</head>
<body>
    <div class="container">
        <h1>🚇 Subway Sign Configuration</h1>
        
        <div class="step">
            <h2>Server Status</h2>
            <p>✅ Server running on: <strong>http://${req.get('host')}</strong></p>
            <p>📡 Test API: <a href="/api/stations" target="_blank">/api/stations</a></p>
        </div>
        
        <div class="step">
            <h2>Step 1: Copy this to Embedded/secrets.py</h2>
            <pre>secrets = {
    # WiFi credentials
    "ssid": "YOUR_WIFI_NAME",
    "password": "YOUR_WIFI_PASSWORD",
    
    # Server configuration
    "server_url": "http://${req.get('host')}",
    
    # Display settings
    "station_id": "G22",  # Greenpoint Av
    "route": "G",
    "brightness": 0.4,    # 0.0 to 1.0
    
    # Update intervals (seconds)
    "fetch_interval": 15,
    "display_refresh": 1,
    
    # Time zone
    "timezone": "America/New_York"
}</pre>
        </div>
        
        <div class="step">
            <h2>Step 2: Available Stations</h2>
            <ul>
                ${Object.values(STATIONS).map(s => 
                  `<li><strong>${s.stop_id}</strong>: ${s.stop_name} (${s.routes.join(', ')})</li>`
                ).join('')}
            </ul>
        </div>
        
        <div class="step">
            <h2>Step 3: Test Your Configuration</h2>
            <p>📊 Monitor: <code>pm2 logs subway-api</code></p>
            <p>🔄 Restart: <code>pm2 restart subway-api</code></p>
        </div>
    </div>
</body>
</html>
  `);
});

/**
 * Health check endpoint
 */
app.get('/health', (req, res) => {
  const memUsage = process.memoryUsage();
  
  res.json({
    status: 'ok',
    uptime: process.uptime(),
    memory: {
      rss: Math.round(memUsage.rss / 1024 / 1024) + 'MB',
      heapUsed: Math.round(memUsage.heapUsed / 1024 / 1024) + 'MB',
      heapTotal: Math.round(memUsage.heapTotal / 1024 / 1024) + 'MB'
    },
    cache: {
      keys: cache.keys().length,
      stats: cache.getStats()
    }
  });
});

// Error handling middleware
app.use((error, req, res, next) => {
  console.error('Unhandled error:', error);
  res.status(500).json({ 
    error: 'Internal server error',
    currentTime: getCurrentTime()
  });
});

// 404 handler
app.use((req, res) => {
  res.status(404).json({ error: 'Endpoint not found' });
});

// Start server
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🚇 Subway Sign Server running on port ${PORT}`);
  console.log(`📡 Local access: http://localhost:${PORT}`);
  console.log(`🔧 Config page: http://localhost:${PORT}/config`);
  console.log(`💾 Memory limit: ${process.env.NODE_OPTIONS || '384MB'}`);
  
  if (!MTA_API_KEY) {
    console.warn('⚠️  No MTA_API_KEY found in .env - using keyless access');
  }
});
